<?php
include("index.php");
include("conexion.php");

$model = $_POST['txtModel'];
$brand = $_POST['txtBrand'];
$stock = $_POST['txtStock'];
$processor = $_POST['txtProcessor'];
$color = $_POST['txtColor'];
$storage = $_POST['txtStorage'];
$price = $_POST['txtPrice'];
$isitupgradable = $_POST['txtRadio'];

// Manejo del archivo
$uploadDir = "uploads/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$filename = basename($_FILES["txtPhoto"]["name"]);
$targetFile = $uploadDir . $filename;
$imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

$allowed = ["jpg", "jpeg", "png", "gif"];
if (!in_array($imageFileType, $allowed)) {
    die("Solo se permiten archivos JPG, PNG o GIF.");
}

if (!move_uploaded_file($_FILES["txtPhoto"]["tmp_name"], $targetFile)) {
    die("Error al subir la imagen.");
}

// Insertar en base de datos
$sql = "INSERT INTO computers (model, brand, stock, processor, imagepath, color, storage, price, isitupgradable) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conexion, $sql);
mysqli_stmt_bind_param($stmt, "ssisssdis", 
    $model, 
    $brand, 
    $stock, 
    $processor, 
    $targetFile, 
    $color, 
    $storage, 
    $price, 
    $isitupgradable
);


if (mysqli_stmt_execute($stmt)) {
    echo "✅ Computadora registrado correctamente.";
    echo "<br><a href='index.php'>Volver</a>";
} else {
    echo "❌ Error al registrar la computadora: " . mysqli_error($conexion);
}

mysqli_close($conexion);
?>
