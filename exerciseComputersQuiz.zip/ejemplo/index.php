<?php
$servidor = "localhost";
$usuario = "root";
$clave = "";
$bd = "computersbd";

$conexion = mysqli_connect($servidor, $usuario, $clave, $bd);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Computers Registration</title>
    <script>
        function validateForm() {
            const model = document.forms["frmComputers"]["txtModel"].value;
            const type = document.forms["frmComputers"]["txtBrand"].value;
            const stock = document.forms["frmComputers"]["txtStock"].value;
            const processor = document.forms["frmComputers"]["txtProcessor"].value;
            const file = document.forms["frmComputers"]["txtPhoto"].value;
            const type = document.forms["frmComputers"]["txtColor"].value;
            const storage = document.forms["frmComputers"]["txtStorage"].value;
            const price = document.forms["frmComputers"]["txtPrice"].value;
            const brand = document.forms["frmComputers"]["txtBrand"].value;
            const brand = document.forms["frmComputers"]["txtBrand"].value;
            const radios = document.forms["frmComputers"]["txtRadio"];

            const regexModel = /^[A-Za-z0-9\s\-]{2,30}$/;
            const currentYear = new Date().getFullYear();

            if (!regexModel.test(model&&brand)) {
                alert("Invalid model. Only letters, numbers and hyphens allowed.");
                return false;
            }

            if (!type) {
                alert("Please select a computer type.");
                return false;
            }

            let radioChecked = false;
            for (let i = 0; i < radios.length; i++) {
                if (radios[i].checked) {
                    radioChecked = true;
                    break;
                }
            }
            if (!radioChecked) {
                alert("Please select if it is an upgradable computer");
                return false;
            }

            if (!file) {
                alert("Please select an image file.");
                return false;
            }

            if (file && !(/\.(jpg|jpeg|png|gif)$/i).test(file)) {
                alert("Only image files (JPG, PNG, GIF) are allowed.");
                return false;
            }

            return true;
        }
    </script>
</head>
<body>
    <h1>COMPUTERS REGISTRATION</h1>
    <hr size="3">
    <form name="frmComputers" action="insert.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
        <table>
            <tr>
                <td>Model:</td>
                <td><input type="text" name="txtModel" required></td>
            </tr>
            <tr>
                <td>Brand:</td>
                <td>
                    <select name="txtBrand" required>
                        <option value="">Select</option>
                        <option value="HP">HP</option>
                        <option value="SAMSUNG">SAMSUNG</option>
                        <option value="LG">LG</option>
                        <option value="VIEWSONIC">VIEWSONIC</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Stock:</td>
                <td><input type="text" name="txtStock" required></td>
            </tr>
            <tr>
                <td>Processor:</td>
                <td><input type="text" name="txtProcessor" required></td>
            </tr>
            <tr>
                <td>Image file of computer:</td>
                <td><input type="file" name="txtPhoto" accept="image/*"></td>
            </tr>
            <tr>
                <td>Color:</td>
                <td>
                    <select name="txtColor" required>
                        <option value="">Select</option>
                        <option value="BLACK">BLACK</option>
                        <option value="WHITE">WHITE</option>
                        <option value="GRAY">GRAY</option>
                        <option value="PINK">PINK</option>
                    </select>
            </tr>
            <tr>
                <td>Storage:</td>
                <td><input type="text" name="txtStorage" required></td>
            </tr>
            <tr>
                <td>Price:</td>
                <td><input type="text" name="txtPrice" required></td>
            </tr>
            <tr>
                <td>Is it upgradable?</td>
                <td>
                    <input type="radio" name="txtRadio" value="Yes" required> Yes <br>
                    <input type="radio" name="txtRadio" value="No" required> No <br>
                </td>
            </tr>
            
            <tr>
                <td>Send:</td>
                <td><input type="submit" name="btnSubmit" value="Register"></td>
            </tr>
        </table>
    </form>
    <hr>
<h2>Registered Computers</h2>

<?php
// Conexión (asegúrate de que ya exista, si no, vuelve a conectar aquí)
$conexion = mysqli_connect("localhost", "root", "", "computersbd");
if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

$sql = "SELECT model, brand, stock, processor, imagepath, color, storage, price, isitupgradable  FROM computers";
$resultado = mysqli_query($conexion, $sql);

if (mysqli_num_rows($resultado) > 0): ?>
    <table border="1" cellpadding="9" cellspacing="0">
        <tr>
            <th>Model</th>
            <th>Brand</th>
            <th>Stock</th>
            <th>Processor</th>
            <th>Color</th>
            <th>Storage</th>
            <th>Price</th>
            <th>Is it upgradable?</th>
            <th>Image</th>
        </tr>
        <?php while ($fila = mysqli_fetch_assoc($resultado)): ?>
        <tr>
            <td><?= htmlspecialchars($fila['model']) ?></td>
            <td><?= htmlspecialchars($fila['brand']) ?></td>
            <td><?= htmlspecialchars($fila['stock']) ?></td>
            <td><?= htmlspecialchars($fila['processor']) ?></td>
            <td><?= htmlspecialchars($fila['color']) ?></td>
            <td><?= htmlspecialchars($fila['storage']) ?></td>
            <td><?= htmlspecialchars($fila['price']) ?></td>
            <td><?= htmlspecialchars($fila['isitupgradable']) ?></td>
            <td>
                <?php if (!empty($fila['imagepath'])): ?>
                    <img src="<?= htmlspecialchars($fila['imagepath']) ?>" width="100">
                <?php else: ?>
                    No image
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p>Still no computers...</p>
<?php endif;

mysqli_close($conexion);
?>

    <hr size="3">
    <br>
    This is the web page for registering xomputers. <br>
    Please fill all the fields.<br>
    Remember to <strong>save</strong> the information at the end of your process. <br>
</body>
</html>
